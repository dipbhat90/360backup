<?php include 'header.php'; ?>
<div class="position-relative">
    <div class="shape overflow-hidden">
        <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
        </svg>
    </div>
</div>
<!-- banner bottom shape -->
<section class="w3l-blogblock py-5">
    <div class="container pt-lg-4 pt-md-3">
        <div class="item">
            <div class="row">
                <div class="col-lg-6">
                    <a href="blog-single.html">
                        <img class="card-img-bottom d-block radius-image-full" src="assets/images/founder.jpeg"
                            alt="Card image cap" style="height:200px; width:250px;">
                    </a>
                </div>
                <div class="col-lg-6 blog-details align-self mt-lg-0 mt-4">
                    <a href="" class="blog-desc-big">Geeta Devi
                    </a>
                    <div class="entry-meta mb-3"> 
                        <span class="comments-link"> <a href="">Founder</a> </span> /
                       
                    </div>
                    <p>Founder Geeta Devi a woman who fighting from illiteracy and women and child development of the society as well as depressed class also.</p>
                   
                </div>
            </div>
        </div>
        <div class="item mt-5">
            <div class="row">
                <div class="col-lg-6">
                    <a href="blog-single.html">
                        <img class="card-img-bottom d-block radius-image-full" src="assets/images/founder1.jpeg"
                            alt="Card image cap" style="height:200px; width:250px;">
                    </a>
                </div>
                <div class="col-lg-6 blog-details align-self mt-lg-0 mt-4">
                    <a href="" class="blog-desc-big">Niju Kumar Ram (B.S.S.S)
                    </a>
                    <p>Former District President, Aawas sahayak karmi sangh, West Champaran, Bettiah</p>
                    <p>District President, SC/ST Kramchari Sangh, Sheohar</p>
                    <div class="entry-meta mb-3"> 
                        <span class="comments-link"> <a href="">Co-Founder</a> </span> /
                       
                    </div>
                    <p>Co-Founder Niju Kumar Ram (B.S.S.S) working for Old Age Person,Widow,Disable and Beggars of the society . De-Addiction program is a major project of charity . Society has an endless reason for charity because some problems never show their solution. Only charity, singing, research paper and other literacy work can reduce these problems of the society.</p>
                   
                </div>
            </div>
        </div>
        <div class="item mt-5">
            <div class="row">
                <div class="col-lg-6">
                    <a href="blog-single.html">
                        <img class="card-img-bottom d-block radius-image-full" src="assets/images/founder2.jpeg"
                            alt="Card image cap" style="height:200px; width:250px;">
                    </a>
                </div>
                <div class="col-lg-6 blog-details align-self mt-lg-0 mt-4">
                    <a href="" class="blog-desc-big">Kamal Deo Ram
                    </a>
                    <p>Social worker</p>
                 
                    <div class="entry-meta mb-3"> 
                        <span class="comments-link"> <a href="">Co-Founder</a> </span> /
                       
                    </div>
                    
                   
                </div>
            </div>
        </div>
          <div class="item mt-5">
            <div class="row">
                <div class="col-lg-6">
                    <a href="blog-single.html">
                        <img class="card-img-bottom d-block radius-image-full" src="assets/images/founder3.jpeg"
                            alt="Card image cap" style="height:200px; width:250px;">
                    </a>
                </div>
                <div class="col-lg-6 blog-details align-self mt-lg-0 mt-4">
                    <a href="" class="blog-desc-big">Kanchan Devi
                    </a>
                    <p>Social worker</p>
                 
                    <div class="entry-meta mb-3"> 
                        <span class="comments-link"> <a href="">Co-Founder</a> </span> /
                       
                    </div>
                    
                   
                </div>
            </div>
        </div>
       
       
      
         <!-- pagination -->
        
        <!-- //pagination -->
    </div>
</section>
	<?php include 'footer.php'; ?>