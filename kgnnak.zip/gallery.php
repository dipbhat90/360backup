<?php include 'header.php'; ?>
<div class="inner-banner">
    <section class="w3l-breadcrumb py-5">
        <div class="container py-lg-5 py-md-3">
            <h2 class="title">Gallery</h2>
        </div>
    </section>
</div>
<!-- banner bottom shape -->
<div class="position-relative">
    <div class="shape overflow-hidden">
        <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
        </svg>
    </div>
</div>
<!-- banner bottom shape -->
<!--/causes-sec-->
<div class="w3-services py-5">
    <div class="container py-lg-4 py-md-3">
        <div class="row w3-services-grids">
            <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                   
                   
                  <img src="assets/images/gallery.jpeg" class="img-fuild radius-image-full"
                            alt="" style="height:300px;">
                </div>
            </div>
            <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                 
                  
                    <img src="assets/images/gallery5.jpeg" class="img-fuild radius-image-full" alt="" style="height:300px;">
                </div>
            </div>
            <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                    
                   
                   <img src="assets/images/gallery1.jpeg" class="img-fuild radius-image-full" alt="" style="height:300px;">
                </div>
            </div>
            <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                    
                   
                    <img src="assets/images/gallery2.jpeg" class="img-fuild radius-image-full" alt="" style="height:300px;">
                </div>
            </div>
            <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                   
                  
                    <img src="assets/images/gallery3.jpeg" class="img-fuild radius-image-full" alt="" style="height:300px;">
                </div>
            </div>
            <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                    
                   
                    <img src="assets/images/gallery4.jpeg" class="img-fuild radius-image-full" alt="" style="height:300px;">
                </div>
            </div>
             <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                    
                   
                    <img src="assets/images/gallery6.jpeg" class="img-fuild radius-image-full" alt="" style="height:300px;">
                </div>
            </div>
             <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                    
                   
                    <img src="assets/images/gallery7.jpeg" class="img-fuild radius-image-full" alt="" style="height:300px;">
                </div>
            </div>
        </div>
    </div>
</div>
<!--/causes-sec-->

<?php include 'footer.php'; ?>