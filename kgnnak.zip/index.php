<?php include 'header.php'; ?>
<!-- main-slider -->
<!--<section class="w3l-main-slider" id="home">
    <div class="companies20-content">
        <div class="owl-one owl-carousel owl-theme">
           <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9926441399266089"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2541881773136748"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5618094032078901"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2220403239029851"
     crossorigin="anonymous"></script>
	 
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7528823209630874"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3812110918801530"
     crossorigin="anonymous"></script>	 
            <div class="item">
                <li>
                    <div class="slider-info banner-view banner-top3 bg bg2">
                        
                        <div class="banner-info">
                            <div class="container">
                                <div class="banner-info-bg text-left">
                                    <p>Unconditional Help</p>
                                    <h5>Should Children suffer this way? Don't leave Orphans alone</h5>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </div>
             <div class="item">
                <li>
                    <div class="slider-info banner-view bg bg2">
                        <div class="banner-info">
                            <div class="container">
                                <div class="banner-info-bg text-left">
                                    <p>Charity Life</p>
                                    <h5>Charity, Faith and Hope. Help the Homeless. Charity life.</h5>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </div>
           
            
        </div>
    </div>
</section>-->

<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
   <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9926441399266089"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2541881773136748"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5618094032078901"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2220403239029851"
     crossorigin="anonymous"></script>
	 
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7528823209630874"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3812110918801530"
     crossorigin="anonymous"></script>	 
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
    
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="assets/images/banner4.jpg" class="d-block w-100" alt="...">
     
    </div>
    <div class="carousel-item">
      <img src="assets/images/banner1.jpg" class="d-block w-100" alt="...">
     
    </div>
   
  </div>
  <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
    <span class="" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
    <span class="" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- /main-slider -->
<!-- banner image bottom shape -->
<div class="position-relative">
    <div class="shape overflow-hidden">
        <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor">
            </path>
        </svg>
    </div>
</div>
<!-- //banner image bottom shape -->
<!-- home page block1 -->
<section class="homeblock1">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="box-wrap">
                    <h4><a href="#mission">View our Mission</a></h4>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12 mt-md-0 mt-sm-4 mt-3">
                <div class="box-wrap">
                    <h4><a href="team.php">Top Founders</a></h4>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12 mt-lg-0 mt-sm-4 mt-3">
                <div class="box-wrap">
                    <h4><a href="contact.php">Requst a Quote</a></h4>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- //home page block1 -->
<!-- middle -->
	<div class="middle py-5" id="facts">
		<div class="container pt-lg-3">
			<div class="welcome-left text-center py-md-5 py-3">
                <h3 class="title-big">Over 93% of all Donations go directly to Projects.</h3>
                <p style="text-align:center;">Under 7% for admin, fundraising, and salaries.</p>
                <h4>Thank you for your continued Support </h4>
				<a href="donation.php" class="btn btn-style btn-primary mt-sm-5 mt-4"><span class="fa fa-heart mr-1"></span> Donate Now</a>
			</div>
		</div>
	</div>
	<!-- //middle -->

<!-- /bottom-grids-->
<section class="w3l-bottom-grids-6 py-5">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="grids-area-hny main-cont-wthree-fea row">
            <div class="col-lg-4 col-md-6 grids-feature">
                <div class="area-box">
                    <img src="assets/images/donate.png" alt="">
                    <h4><a href="#feature" class="title-head">Give Donation.</a></h4>
                    <p class="mb-3">Donating to charity is a powerful way to make a positive impact on the world and contribute to meaningful causes.</p>
                    <a href="donation.php" class="btn btn-text">Donate Now </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 grids-feature mt-md-0 mt-5">
                <div class="area-box">
                    <img src="assets/images/volunteer.png" alt="">
                    <h4><a href="#feature" class="title-head">Become a Volunteer.</a></h4>
                    <p class="mb-3">Joining a charity as a volunteer is a commitment to creating positive change and leaving a lasting impact on the lives of those less fortunate..</p>
                    <a href="contact.php" class="btn btn-text">Join Now </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 grids-feature mt-lg-0 mt-5">
                <div class="area-box">
                    <img src="assets/images/child.png" alt="" width="52px"> 
                    <h4><a href="#feature" class="title-head">Help the Children, Old age, women and Disable</a></h4>
                    <p class="mb-3">Let us stand united in our dedication to shaping a brighter future for the children who hold the keys to tomorrow. .</p>
                    <a href="donation.php" class="btn btn-text">Help Now </a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- //bottom-grids-->
<!-- stats -->
<section class="w3_stats py-5" id="stats">
    <div class="container py-lg-5 py-md-4 py-2">
       
        <div class="w3-stats text-center">
            <div class="row">
                <div class="col-md-6 col-6">
                    <div class="counter">
                        <span class="fa fa-users"></span>
                        <div class="timer count-title count-number mt-3" data-to="1500" data-speed="1500"></div>
                        <p style="text-align:center;">Total Volunteers</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="counter">
                        <span class="fa fa-cutlery"></span>
                        <div class="timer count-title count-number mt-3" data-to="2256" data-speed="1500"></div>
                        <p style="text-align:center;">Meals Served</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="counter">
                        <span class="fa fa-home"></span>
                        <div class="timer count-title count-number mt-3" data-to="1000" data-speed="1500"></div>
                        <p style="text-align:center;">Got Shelter</p>
                    </div>
                </div>
               
            </div>
        </div>
    </div>
</section>
<!-- //stats -->
<!-- bg -->
<div class="">

    <div class="container py-lg-5 py-md-4">
        
        <div class="welcome-left text-center py-lg-4">
            <span class="fa fa-heart-o"></span>
            <h3 class="title-big">Help the Homeless & Hungry People.</h3>
            <a href="donation.php" class="btn btn-style btn-primary mt-sm-5 mt-4">Donate Now</a>
        </div>
    </div>
</div>
<!-- //bg -->
<section class="w3l-index5 py-5" id="causes">
    <div class="container py-lg-5 py-md-4">
        <div class="row">
            <div class="col-lg-4">
                <div class="header-section">
                    <h3 class="title-big">Our Charity Causes </h3>
                    <h4>If you want to work with for Save Poor charity? <a href="#url">Send your Details.</a></h4>
                    <p class="mt-3 mb-lg-5 mb-4"> "At KGNAAK, we are driven by a profound commitment to making a positive impact in the world. Our diverse range of charitable causes is fueled by the belief that every individual deserves access to basic necessities, education, and healthcare. From supporting underprivileged communities to championing environmental sustainability, we strive to create a lasting change that transcends borders. </p>
                </div>
                <a href="contact.php" class="btn btn-outline-primary btn-style">Contact Us</a>
            </div>
            <div class="col-lg-4 col-md-6 mt-lg-0 mt-5">
                <div class="img-block">
                    <a href="">
                        <img src="assets/images/children1.webp" class="img-fluid radius-image-full" alt="image" />
                        <span class="title">Food for Hungry</span>
                    </a>
                </div>
                <div class="img-block mt-4">
                    <a href=""> <img src="assets/images/child.jpg" class="img-fluid radius-image-full"
                            alt="image" />
                        <span class="title">Help from Injuries</span>
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mt-lg-0 mt-md-5 mt-4">
                <div class="img-block">
                    <a href=""> <img src="assets/images/child1.jpg" class="img-fluid radius-image-full"
                            alt="image" />
                        <span class="title">Education for all</span>
                    </a>
                </div>
                <div class="img-block mt-4">
                    <a href="">
                        <img src="assets/images/blog4.jpg" class="img-fluid radius-image-full" alt="image" />
                        <span class="title">Clean water for all</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="w3-services-ab py-5" id="mission">
    <div class="container py-lg-5 py-md-4">
        <h3 style="text-align:center;">Our Mission</h3>
        <p>Our mission is to serve and aware people from their rights and duties, techniques for social security and also socio-economic development training programme. Skilled life style achievement programme.</p><br>
        <div class="w3-services-grids">
            <div class="fea-gd-vv row">
                <div class="col-lg-4 col-md-6">
                    <div class="float-lt feature-gd">
                        <div class="icon">
                            <img src="assets/images/home.png" alt="" class="img-fluid">
                        </div>
                        <div class="icon-info">
                            <h5>Homeless Charities.</h5>
                            <p>Homeless charities often focus on addressing the root causes of homelessness, such as unemployment, mental health issues, and substance abuse. </p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-md-0 mt-4">
                    <div class="float-mid feature-gd">
                        <div class="icon">
                            <img src="assets/images/education.png" alt="" class="img-fluid">
                        </div>
                        <div class="icon-info">
                            <h5>Education Charities.</h5>
                            <p> 
Education charities play a crucial role in addressing disparities in access to quality education and promoting learning opportunities for individuals around the world. </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-lg-0 mt-4">
                    <div class="float-rt feature-gd">
                        <div class="icon">
                            <img src="assets/images/health.png" alt="" class="img-fluid">
                        </div>
                        <div class="icon-info">
                            <h5>Health Charities.</h5>
                            <p> 
Health charities play a crucial role in addressing and mitigating various health challenges faced by individuals and communities globally.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-4 pt-md-2">
                    <div class="float-lt feature-gd">
                        <div class="icon">
                            <img src="assets/images/education.png" alt="" class="img-fluid">
                        </div>
                        <div class="icon-info">
                            <h5>Training</h5>
                            <p> Major programmes include online training, online awareness programs, lectures and talk show with major personalities</p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-4 pt-md-2">
                    <div class="float-lt feature-gd">
                        <div class="icon">
                            <img src="assets/images/food.png" alt="" class="img-fluid">
                        </div>
                        <div class="icon-info">
                            <h5>Economic involvement.</h5>
                            <p> Special focus on the chapter of economic involvement by the depressed class society of concerned region of the universe. </p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-4 pt-md-2">
                    <div class="float-lt feature-gd">
                        <div class="icon">
                            <img src="assets/images/eco.png" alt="" class="img-fluid">
                        </div>
                        <div class="icon-info">
                            <h5>Drugs addiction</h5>
                            <p>Online programmes for drugs de-Addiction in the backward societies living standard and report on the economic harassment from drugs addiction in developing countries </p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<?php include 'footer.php'; ?>