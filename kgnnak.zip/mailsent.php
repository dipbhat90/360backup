<?php 
if(isset($_POST['submit'])){
	
$mailto = "geetaaaaa05082704@gmail.Com, knijurama@gmail.com";
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

$phone = $_POST['phone'];

$subject= "Confirmation: Message was submitted successfully";

$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>

<table>
<tr>
<th>Name</th>
<th>email</th>
<th>message</th>

<th>Phone</th>
</tr>
<tr>
<td>".$name."</td>
<td>".$email."</td>
<td>".$message."</td>

<td>".$phone."</td>
</tr>
</table>
</body>
</html>
";



// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";



 $result= mail($mailto, $subject, $message, $headers);



?>
<script>

alert('Submitted Successfully');
window.location ='index.php';

</script>
<?php 
}
else{
	echo 'failed';
}