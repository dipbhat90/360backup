<?php include 'header.php'; ?>
<div class="inner-banner">
    <section class="w3l-breadcrumb py-5">
        <div class="container py-lg-5 py-md-3">
            <h2 class="title">Mission</h2>
        </div>
    </section>
</div>
<!-- banner bottom shape -->
<div class="position-relative">
    <div class="shape overflow-hidden">
        <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
        </svg>
    </div>
</div>
<!-- banner bottom shape -->
<!--/causes-sec-->
<div class="w3-services py-5">
    <div class="container py-lg-4 py-md-3">
        <div class="row w3-services-grids">
            <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                    <a href="#cause" class="cause-title-wrap">
                       
                        <h4 class="cause-title">Women Helpline
                        </h4>
                        <a href="tel:181">
                        <p class="counter-inherit">
                              181
                        </p>
                        </a>
                    </a>
                    <div class="barWrapper my-4">
                        <div class="progress-box">
                            <div class="progress" data-value="60">
                                <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0"
                                    aria-valuemax="100" style="width: 60%;">
                                    <div class="value-holder"><span class="value"></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a href="tel:181"><img src="assets/images/Helpline.jpg" style="height:200px;"class="img-fuild radius-image-full"
                            alt=""></a>
                </div>
            </div>
             <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                    <a href="#cause" class="cause-title-wrap">
                       
                        <h4 class="cause-title">Elderline
                        </h4>
                         <a href="tel:14567">
                        <p class="counter-inherit">
                              14567
                        </p>
                        </a>
                    </a>
                    <div class="barWrapper my-4">
                        <div class="progress-box">
                            <div class="progress" data-value="60">
                                <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0"
                                    aria-valuemax="100" style="width: 60%;">
                                    <div class="value-holder"><span class="value"></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a href="blog-single.html"><img src="assets/images/elder.jpg" style="height:200px;" class="img-fuild radius-image-full"
                            alt=""></a>
                </div>
            </div>
              <div class="col-lg-4 col-md-6 causes-grid">
                <div class="causes-grid-info">
                    <a href="#cause" class="cause-title-wrap">
                       
                        <h4 class="cause-title">Childline
                        </h4>
                         <a href="tel:1098">
                        <p class="counter-inherit">
                              1098
                        </p>
                        </a>
                    </a>
                    <div class="barWrapper my-4">
                        <div class="progress-box">
                            <div class="progress" data-value="60">
                                <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0"
                                    aria-valuemax="100" style="width: 60%;">
                                    <div class="value-holder"><span class="value"></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a href="blog-single.html"><img src="assets/images/line.jpg" style="height:200px;" class="img-fuild radius-image-full"
                            alt=""></a>
                </div>
            </div>
           
           
          
           
           
        </div>
    </div>
</div>
<!--/causes-sec-->

<?php include 'footer.php'; ?>
