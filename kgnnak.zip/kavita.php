<?php include 'header.php'; ?>
<div class="inner-banner">
    <section class="w3l-breadcrumb py-5">
        <div class="container py-lg-5 py-md-3">
            <h2 class="title">literary Work </h2>
        </div>
    </section>
</div>
<!-- banner bottom shape -->
<div class="position-relative">
    <div class="shape overflow-hidden">
        <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
        </svg>
    </div>
</div>
<!-- banner bottom shape -->
<!--/causes-sec-->
<div class="w3-services py-5">
    <div class="container py-lg-4 py-md-3">
        <div class="row w3-services-grids">
            <div class="col-lg-4 col-md-6 causes-grid">
                <div class="">
                   
                   
            
                   <iframe src="https://hindi.pratilipi.com/read/%E0%A4%B0%E0%A4%B9%E0%A4%A8%E0%A5%81%E0%A4%AE%E0%A4%BE-epxw0jrzrhfi-96881g4713s1x61" height="400" width="100%" title="Iframe Example"></iframe>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 causes-grid">
                <div class="">
                 
                  
                   <iframe src="https://hindi.pratilipi.com/read/%E0%A4%95%E0%A5%8D%E0%A4%B7%E0%A4%BF%E0%A4%A4%E0%A4%BF%E0%A4%9C-ebauxausibfc-c86m816f3108221" height="400" width="100%" title="Iframe Example"></iframe>
                </div>
            </div>
           
            
            
            
             
            
        </div>
    </div>
</div>
<!--/causes-sec-->

<?php include 'footer.php'; ?>