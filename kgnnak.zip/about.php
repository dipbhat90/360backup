<?php include 'header.php'; ?>
<div class="inner-banner">
    <section class="w3l-breadcrumb py-5">
        <div class="container py-lg-5 py-md-3">
            <h2 class="title" style="color:yellow;">“सभ्य होने की पहचान, कल्याण और त्याग से होती है ।”</h2>
        </div>
    </section>
</div>
<!-- banner bottom shape -->
<div class="position-relative">
    <div class="shape overflow-hidden">
        <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
        </svg>
    </div>
</div>
<!-- banner bottom shape -->
<section class="w3l-aboutblock1 py-5" id="about">
    <div class="container py-lg-5 py-md-3">
        <div class="row">
            <div class="col-lg-6">
                <h5 class="title-small">A little about Us</h5>
                <h3 class="title-big">Welcome to KGNAAK charity</h3>
                <p class="mt-3">Charity plays a pivotal role in fostering a compassionate and interconnected society. It is a selfless act of giving, whether through financial contributions, volunteering time, or donating resources, with the primary aim of alleviating the suffering of others. Charitable initiatives address a myriad of social issues, ranging from poverty and hunger to education and healthcare. The power of charity lies not only in its capacity to provide immediate relief but also in its ability to create lasting, positive change. </p>
               
                <h3 class="title mt-4">"Over 20 Years of Accomplishments”</h3>
               
            </div>
            <div class="col-lg-6 mt-lg-0 mt-5">
                <img src="assets/images/about1.jpeg" alt="" class="radius-image img-fluid">
            </div>
        </div>
    </div>
</section>
 <!-- forms -->
 <section class="w3l-forms-9 py-5" id="">
     <div class="main-w3 py-lg-5 py-md-3">
         <div class="container">
             <div class="row align-items-center">
                 <div class="main-midd col-lg-9">
                     <h3 class="title-big">Facts about KGNAAK charity</h3>
                     <p class="mt-3">A lot of work goes down at the grass root level in villages in the remotest corners
                         as
                         well as the most populous metros across India, with schools and government bodies.
                         We need your contributions to keep coming in.</p>
                 </div>
                 <div class="main-midd-2 col-lg-3 mt-lg-0 mt-4 text-lg-right">
                     <a class="btn btn-style btn-primary" href="donation.php"><span class="fa fa-heart mr-1"></span> Donate
                         Now </a>
                 </div>
             </div>

             <div class="donar-img mt-5">
                <div class="right-side text-center">
                    <span class="fa fa-heart"></span>
                    <p>OUR TOP DONAR</p>
                    
                  
                </div>
            </div>
         </div>
     </div>
 </section>
 <!-- //forms -->


<!--//team-sec-->

  <!-- //testimonials -->
	<?php include 'footer.php'; ?>