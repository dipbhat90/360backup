 <?php include 'header.php'; ?>
<div class="inner-banner">
    <section class="w3l-breadcrumb py-5">
        <div class="container py-lg-5 py-md-3 text-center">
            <h4 class="title">Your Support can Make a Huge Difference</h4>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li>Donate</li>
            </ul>
        </div>
    </section>
</div>
<!-- banner bottom shape -->
<div class="position-relative">
    <div class="shape overflow-hidden">
        <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
        </svg>
    </div>
</div>
<!-- banner bottom shape -->
<!-- donate -->
<section class="w3l-donate py-5" id="donate">
    <div class="container py-lg-5 py-md-4">
        <div class="row">
            <div class="col-lg-4">
                <div class="donate-details mt-0">
                    <h5 class="mb-3">Our payment details</h5>
                   
                    <div class="barcode-details">
                        <img src="assets/images/qr1.jpeg" alt="" class="mt-4 img-fluid">
                    </div>
                    
                </div>
            </div>
            <div class="col-lg-8 mt-lg-0 mt-4">
                <div class="donate-details mt-0">
                    <h5 class="mb-3">Our payment details</h5>
                   
                    <div class="barcode-details">
                        <img src="assets/images/qr2.jpeg" alt="" class="mt-4 img-fluid">
                    </div>
                   
                </div>
            </div>
        </div>
</section>
	<?php include 'footer.php'; ?>