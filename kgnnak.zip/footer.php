<!-- footer 14 -->
<div class="w3l-footer-main">
  <div class="w3l-sub-footer-content">
     <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9926441399266089"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2541881773136748"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5618094032078901"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2220403239029851"
     crossorigin="anonymous"></script>
	 
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7528823209630874"
     crossorigin="anonymous"></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3812110918801530"
     crossorigin="anonymous"></script>	 
      <!-- Footers-14 -->
      <footer class="footer-14" style=" background:black;">
          <div id="footers14-block">
              <div class="">
                  <div class="footers-content">
                      <div class=" grid-col-4 grids-content">
                          <div class="column">
                              <h4>Our Address</h4>
                                <p style="text-align:center;">Office address-Villege- phooljhariya, Post-Bathna, Police station-Bairiya, District-West Champaran, Bettiah, Bihar 845438.</p>
                          </div>
                          <div class="column">
                              <h4>Call Us</h4>
                              <p style="text-align:center;">Mon - Fri 10:30 -18:00</p>
                              <p style="text-align:center;"><a href="tel:+919431846546">+919431846546</a></p>
                          </div>
                          <div class="column">
                              <h4>Mail Us</h4>
                              <p style="text-align:center;"><a href="Geetaaaaa05082704@gmail.com"><span class="" data-cfemail="">Geetaaaaa05082704@gmail.com</span></span></a></p>
                              <p style="text-align:center;"><a href="Knijurama@gmail.com"><span class="" data-cfemail="">Knijurama@gmail.com</span></a></p>
                          </div>
                          <div class="column">
                              <h4>Follow Us On</h4>
                              <ul>
                                  <li><a href="https://www.facebook.com/niju.ram.9"><span class="fa fa-facebook"
                                              aria-hidden="true"></span></a>
                                  </li>
                                  <li><a href="https://www.instagram.com/nijukumarram/"><span class="fa fa-instagram"
                                              aria-hidden="true"></span></a>
                                  </li>
                                  <li><a href="https://twitter.com/knijurama/status/1738969425402028099?s=61&t=MMVluAetVhf_mbsjEG9oIQ"><span class="fa fa-twitter"
                                              aria-hidden="true"></span></a>
                                  </li>
                                  <li><a href="https://www.youtube.com/@nijuramak"><span class="fa fa-youtube
                                              aria-hidden="true"></span></a>
                                  </li>
                                 
                              </ul>
                          </div>
                      </div>
                  </div>
                  <div class="">
                      <div class="copyright">
                          <p style="text-align:center;">© 2024  All rights reserved. Design by <a href="https://360lution.com/"
                                  target="_blank">360lution Pvt.Ltd.</a></p>
                      </div>
                     
                  </div>
              </div>
          </div>
          <!-- move top -->
          <button onclick="topFunction()" id="movetop" title="Go to top">
              &uarr;
          </button>
          <script data-cfasync="false" src="../../../../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
              // When the user scrolls down 20px from the top of the document, show the button
              window.onscroll = function () {
                  scrollFunction()
              };

              function scrollFunction() {
                  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                      document.getElementById("movetop").style.display = "block";
                  } else {
                      document.getElementById("movetop").style.display = "none";
                  }
              }

              // When the user clicks on the button, scroll to the top of the document
              function topFunction() {
                  document.body.scrollTop = 0;
                  document.documentElement.scrollTop = 0;
              }
          </script>
          <!-- /move top -->

      </footer>
      <!-- Footers-14 -->
  </div>
</div>
<!-- //footer 14 -->

<script src="assets/js/jquery-3.3.1.min.js"></script> <!-- Common jquery plugin -->

<script src="assets/js/theme-change.js"></script><!-- theme switch js (light and dark)-->
<script src="assets/js/owl.carousel.js"></script>

<!-- script for banner slider-->
<script>
  $(document).ready(function () {
    $('.owl-one').owlCarousel({
      loop: true,
      dots: false,
      margin: 0,
      nav: true,
      responsiveClass: true,
      autoplay: true,
      autoplayTimeout: 5000,
      autoplaySpeed: 1000,
      autoplayHoverPause: false,
      responsive: {
        0: {
          items: 1
        },
        480: {
          items: 1
        },
        667: {
          items: 1
        },
        1000: {
          items: 1
        }
      }
    })
  })
</script>
<!-- //script -->

<!-- script for tesimonials carousel slider -->
<script>
  $(document).ready(function () {
    $("#owl-demo1").owlCarousel({
      loop: true,
      margin: 20,
      nav: false,
      responsiveClass: true,
      responsive: {
        0: {
          items: 1
        },
        736: {
          items: 1
        },
        1000: {
          items: 2,
          loop: false
        }
      }
    })
  })
</script>
<!-- //script for tesimonials carousel slider -->

<script src="assets/js/counter.js"></script>

<!--/MENU-JS-->
<script>
  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop();

    if (scroll >= 80) {
      $("#site-header").addClass("nav-fixed");
    } else {
      $("#site-header").removeClass("nav-fixed");
    }
  });

  //Main navigation Active Class Add Remove
  $(".navbar-toggler").on("click", function () {
    $("header").toggleClass("active");
  });
  $(document).on("ready", function () {
    if ($(window).width() > 991) {
      $("header").removeClass("active");
    }
    $(window).on("resize", function () {
      if ($(window).width() > 991) {
        $("header").removeClass("active");
      }
    });
  });
</script>
<!--//MENU-JS-->

<!-- disable body scroll which navbar is in active -->
<script>
  $(function () {
    $('.navbar-toggler').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- //disable body scroll which navbar is in active -->

<!--bootstrap-->
<script src="assets/js/bootstrap.min.js"></script>
<!-- //bootstrap-->

<script>(function(){var js = "window['__CF$cv$params']={r:'842376572d2587a5',t:'MTcwNDcwNjY1MS41NjUwMDA='};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../../../../../cdn-cgi/challenge-platform/h/g/scripts/jsd/74bd6362/main.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script></body>


<!-- Mirrored from p.w3layouts.com/demos_new/template_demo/01-09-2020/savepoor-liberty-demo_Free/1012221799/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 08 Jan 2024 09:38:23 GMT -->
</html>