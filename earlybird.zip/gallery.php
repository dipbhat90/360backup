<?php include 'header.php'; ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZG3GPH80J5"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZG3GPH80J5');
</script>
<div class="sidebar_ovelay toggle_btn"></div>
<!-- Header section end -->	<!-- End Header -->
	<!-- Breadcrumb  start -->
	<div class="fit_breadcrumb_wrapper" style="margin-bottom: 0px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<h1 class="bread_title">Gallery</h1>
					<p class="bread_subtitle">Home // Gallery</p>
				</div>
			</div>
		</div>
	</div>
	<!-- Breadcrumb  end -->
	<!-- Recent News section start -->
	<section class="fit_blog_wrapper bg_second our_blog pt_100 pb_100">
		<div class="container">
			<div class="row" style="padding-bottom:25px;">
				<div class="col-lg-3 col-md-12">
					<a href="assets/images/yoga.webp" class="example-image-link" data-lightbox="example-set" data-title="7 Ocean The Fitness Club">
						<img src="assets/images/gallery/23.jpeg" class="example-image" alt="7 Ocean The Fitness Club" title="7 Ocean The Fitness Club" style="height:200px;border-radius:10px;width:300px;">
					</a>
				</div>
				<div class="col-lg-3 col-md-12">
					<a href="assets/images/yoga1.jpg" class="example-image-link" data-lightbox="example-set" data-title="7 Ocean The Fitness Club">
						<img src="assets/images/gallery/24.jpeg" class="example-image" alt="7 Ocean The Fitness Club" title="7 Ocean The Fitness Club" style="height:200px;border-radius:10px;width:300px;">
					</a>
				</div>
				<div class="col-lg-3 col-md-12">
					<a href="assets/images/yoga2.avif" class="example-image-link" data-lightbox="example-set" data-title="7 Ocean The Fitness Club">
						<img src="assets/images/gallery/25.jpeg" class="example-image" alt="7 Ocean The Fitness Club" title="7 Ocean The Fitness Club" style="height:200px;border-radius:10px;width:300px;">
					</a>
				</div>
				<div class="col-lg-3 col-md-12">
					<a href="assets/images/yoga3.jpg" class="example-image-link" data-lightbox="example-set" data-title="7 Ocean The Fitness Club">
						<img src="assets/images/gallery/26.jpeg" class="example-image" alt="7 Ocean The Fitness Club" title="7 Ocean The Fitness Club" style="height:200px;border-radius:10px;width:300px;">
					</a>
				</div>
					<div class="col-lg-3 col-md-12">
					<a href="assets/images/gallery/27.jpeg" class="example-image-link" data-lightbox="example-set" data-title="7 Ocean The Fitness Club">
						<img src="assets/images/gallery/27.jpeg" class="example-image" alt="7 Ocean The Fitness Club" title="7 Ocean The Fitness Club" style="height:200px;border-radius:10px;width:300px;">
					</a>
				</div>
			</div>
		
		
			
		
		</div>
	</section>
	<!-- Recent News section end -->
<?php include 'footer.php'; ?>