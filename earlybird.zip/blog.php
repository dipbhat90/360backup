<?php include 'header.php'; ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZG3GPH80J5"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZG3GPH80J5');
</script>
<div class="sidebar_ovelay toggle_btn"></div>
<!-- Header section end -->	<!-- End Header -->
	<!-- Breadcrumb  start -->
	<div class="fit_breadcrumb_wrapper">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<h1 class="bread_title">Our Blog</h1>
					<p class="bread_subtitle">Home // Our Blog</p>
				</div>
			</div>
		</div>
	</div>
	<!-- Breadcrumb  end -->
	<!-- Recent News section start -->
	<section class="fit_blog_wrapper our_blog  pb_100">
		<div class="container">
			<div class="row">
				<div class="col-xl-9 col-lg-9">
				    	<div class="fit_blog_single blog_single_bg mb_30">
						<img src="assets/images/blog_single_img.jpg" class="img-fluid" alt="image" title="">
						<div class="fit_blog_single_data">
						<a href="">	<h2 class="sigl_blog_ttl">How to Achieve Your Fitness Goals to Lead a Healthy Life?</h2></a>
							<p class="mb-2" style="text-align: justify;letter-spacing: 0.17px;">
							When you have great fitness the world seems perfect and you feel the motivation to conquer your dreams. But if your health isn’t on the right track, your entire life could fall flat. This makes it important to put your health first to live a thriving life. But before that, you should identify your limitations and choose a fitness club that helps you overcome them. <br><br>

                              Through this article, you will learn how to achieve your fitness goals and lead a healthy life ever after. There are plenty of options to achieve fitness but what’s right for you depends on your individual preferences. For instance, the <a href=""> best fitness club in Gurgaon, </a> assuming you reside there, has everything for people with a wide array of needs.

							</p>
							
						</div>
					</div>

					<div class="fit_blog_single blog_single_bg mb_30">
						<img src="assets/images/blog_single.jpg" class="img-fluid" alt="image" title="">
						<div class="fit_blog_single_data">
							<h2 class="sigl_blog_ttl">Five easy and quick lunchbox Swaps to get you eating</h2>
							<p class="mb-2" style="text-align: justify;letter-spacing: 0.17px;">
								The sentiment seems to hold true just by looking at the design, level of equipment and high-quality staff that we have on the premises. This 
								impressive facility takes luxury fitness club to the next level with state-of-the-art equipment, group classes & In-house dietician. Take your 
								training to a whole new level and put yourself through the paces with a killer workout at this club.
							</p>
							
						</div>
					</div>
					<div class="fit_blog_single blog_single_bg mb_30">
						<img src="assets/images/blog_single2.jpg" class="img-fluid" alt="image" title="">
						<div class="fit_blog_single_data">
							<h2 class="sigl_blog_ttl">Shape your body at the best Fitness Club in G-town: Seven Ocean- The Fitness Club!!</h2>
							<p class="mb-2" style="text-align: justify;letter-spacing: 0.17px;">
								We consistently delay our fitness resolutions until next year, next month, or the next day. Let’s face it, that day never comes. Workout commitment 
								is a lifetime decision imperative for your well-being and overall happiness and not just for getting a fabulous summer body. So, get started & join 
								one of the Gyms  and commit to going there regularly. We promise to help you with the best recommendations.
							</p>
							
						</div>
					</div>
					<!--<div class="fit_blog_single blog_single_bg mb_30">-->
					<!--	<img src="assets/images/blog_single.jpg" class="img-fluid" alt="image" title="">-->
					<!--	<div class="fit_blog_single_data">-->
					<!--		<h2 class="sigl_blog_ttl">Five easy and quick lunchbox Swaps to get you eating</h2>-->
					<!--		<p class="mb-2" style="text-align: justify;letter-spacing: 0.17px;">-->
					<!--			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore maguai Ut enim ad minim veniam, quis -->
					<!--			nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat Dis aute irure dolor in reprehenderit in voluptate velit esse cillum -->
					<!--			dolore eu fugiat nulla pariatur.-->
					<!--		</p>-->
					<!--	</div>-->
					<!--</div>-->
				</div>
				<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
					<div class="fit_siglbaner_sldr">
						
						<div class="widget_inner widget">
							<h2 class="footer_title underline_title">Social Network</h2>
							<p class="mb-3">We are Awesome Follow us</p>
							<ul class="common_social">
								<li><a href="#33" class="fit_btn social_btn"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="7px" height="14px"><path fill-rule="evenodd" fill="rgb(186, 186, 186)" d="M6.736,0.000 L5.057,-0.004 C3.171,-0.004 1.952,1.349 1.952,3.441 L1.952,5.031 L0.264,5.031 C0.118,5.031 -0.000,5.158 -0.000,5.316 L-0.000,7.619 C-0.000,7.776 0.118,7.903 0.264,7.903 L1.952,7.903 L1.952,13.713 C1.952,13.870 2.070,13.997 2.216,13.997 L4.418,13.997 C4.564,13.997 4.682,13.869 4.682,13.713 L4.682,7.903 L6.656,7.903 C6.802,7.903 6.920,7.776 6.920,7.619 L6.921,5.316 C6.921,5.240 6.893,5.168 6.843,5.116 C6.794,5.061 6.727,5.031 6.657,5.031 L4.682,5.031 L4.682,3.684 C4.682,3.037 4.825,2.709 5.605,2.709 L6.736,2.708 C6.881,2.708 7.000,2.580 7.000,2.422 L7.000,0.284 C7.000,0.129 6.882,0.000 6.736,0.000 Z"></path></svg></a></li>
								<li><a href="#33" class="fit_btn social_btn"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="17px" height="14px"><path fill-rule="evenodd" fill="rgb(186, 186, 186)" d="M16.531,0.253 C15.856,0.659 15.109,0.952 14.315,1.111 C13.679,0.423 12.773,-0.005 11.770,-0.005 C9.843,-0.005 8.282,1.577 8.282,3.529 C8.282,3.805 8.313,4.076 8.372,4.335 C5.474,4.186 2.904,2.779 1.184,0.642 C0.884,1.163 0.712,1.769 0.712,2.418 C0.712,3.646 1.329,4.726 2.263,5.359 C1.692,5.340 1.154,5.180 0.684,4.916 L0.684,4.960 C0.684,6.673 1.886,8.100 3.481,8.426 C3.189,8.506 2.881,8.552 2.562,8.552 C2.337,8.552 2.119,8.527 1.906,8.487 C2.350,9.891 3.637,10.913 5.163,10.943 C3.970,11.889 2.465,12.456 0.832,12.456 C0.550,12.456 0.272,12.438 -0.001,12.407 C1.543,13.408 3.376,13.994 5.346,13.994 C11.761,13.994 15.268,8.608 15.268,3.936 L15.257,3.478 C15.940,2.982 16.533,2.359 17.000,1.652 C16.374,1.932 15.703,2.123 14.997,2.208 C15.717,1.770 16.269,1.077 16.531,0.253 Z"></path></svg></a></li>
								<li><a href="#33" class="fit_btn social_btn"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="16px" height="19px"><path fill-rule="evenodd" fill="rgb(186, 186, 186)" d="M15.990,8.569 L15.990,13.985 L12.561,13.985 L12.561,8.930 C12.561,7.662 12.065,6.796 10.823,6.796 C9.876,6.796 9.312,7.379 9.064,7.944 C8.973,8.146 8.950,8.425 8.950,8.709 L8.950,13.985 L5.520,13.985 C5.520,13.985 5.566,5.426 5.520,4.538 L8.950,4.538 L8.950,5.877 C8.943,5.887 8.934,5.898 8.927,5.909 L8.950,5.909 L8.950,5.877 C9.405,5.234 10.219,4.316 12.041,4.316 C14.298,4.316 15.990,5.666 15.990,8.569 ZM1.931,-0.015 C0.757,-0.015 -0.010,0.689 -0.010,1.616 C-0.010,2.523 0.735,3.249 1.886,3.249 L1.908,3.249 C3.105,3.249 3.849,2.523 3.849,1.616 C3.826,0.689 3.105,-0.015 1.931,-0.015 ZM0.194,13.985 L3.623,13.985 L3.623,4.538 L0.194,4.538 L0.194,13.985 Z"></path></svg></a></li>
								<li><a href="#33" class="fit_btn social_btn"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="21px" height="14px"><path fill-rule="evenodd" fill="rgb(186, 186, 186)" d="M20.107,1.347 C19.538,0.363 18.919,0.183 17.661,0.114 C16.403,0.032 13.242,-0.002 10.502,-0.002 C7.758,-0.002 4.595,0.032 3.339,0.113 C2.083,0.183 1.463,0.362 0.888,1.347 C0.302,2.327 -0.000,4.018 -0.000,6.993 C-0.000,6.997 -0.000,6.998 -0.000,6.998 C-0.000,7.001 -0.000,7.002 -0.000,7.002 L-0.000,7.003 C-0.000,9.967 0.302,11.669 0.888,12.641 C1.463,13.623 2.081,13.801 3.337,13.884 C4.595,13.956 7.758,13.998 10.502,13.998 C13.242,13.998 16.403,13.956 17.662,13.885 C18.921,13.803 19.539,13.624 20.109,12.642 C20.701,11.670 21.000,9.968 21.000,7.005 C21.000,7.005 21.000,7.002 21.000,7.000 C21.000,7.000 21.000,6.997 21.000,6.995 C21.000,4.018 20.701,2.327 20.107,1.347 ZM7.875,10.815 L7.875,3.179 L14.437,6.998 L7.875,10.815 Z"></path></svg></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Recent News section end -->
	
	<?php include 'footer.php'; ?>