<?php 
if(isset($_POST['submit'])){
	
$mailto = "earlybirdhealthandfitness@gmail.com"; 
$name = $_POST['name'];
$age = $_POST['age'];
$hight = $_POST['hight'];
$weight = $_POST['weight'];
$locality = $_POST['locality'];
$health = $_POST['health'];
$phone = $_POST['phone'];
$email = $_POST['email'];

$subject= "Confirmation: Message was submitted successfully";

$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>

<table>
<tr>
<th>Name</th>
<th>Age</th>
<th>Hight</th>
<th>Weight</th>
<th>Locality</th>
<th>Health</th>
<th>Phone</th>
<th>Email</th>



</tr>
<tr>
<td>".$name."</td>
<td>".$age."</td>
<td>".$hight."</td>
<td>".$weight."</td>
<td>".$locality."</td>
<td>".$health."</td>
<td>".$phone."</td>
<td>".$email."</td>



</tr>
</table>
</body>
</html>
";


//earlybirdhealthandfitness@gmail.com
// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";



 $result= mail($mailto, $subject, $message, $headers);



?>
<script>

alert('Submitted Successfully');
window.location ='index.php';

</script>
<?php 
}
else{
	echo 'failed';
}