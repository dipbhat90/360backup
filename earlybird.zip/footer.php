<!-- Newsletter section start -->
	<section class="fit_newsletter_wrapper">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="fit_news_head">
						<h4 class="call_subheading">Call US Today</h4>
						<h1 class="call_heading">Got A Question? We Would Be Happy To Help!</h1>
						<a href="tel:+919914940926" class="call_number"> 
							<span><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="30px" height="30px"><path fill-rule="evenodd" fill="rgb(255, 255, 255)" d="M27.688,14.474 C27.169,11.446 25.740,8.692 23.562,6.512 C21.265,4.221 18.357,2.766 15.149,2.316 L15.473,-0.001 C19.187,0.517 22.551,2.197 25.210,4.858 C27.731,7.387 29.385,10.572 29.991,14.081 L27.688,14.474 ZM21.034,8.923 C22.551,10.447 23.550,12.364 23.912,14.480 L21.609,14.874 C21.328,13.238 20.560,11.752 19.387,10.578 C18.145,9.335 16.572,8.554 14.843,8.311 L15.168,5.994 C17.402,6.306 19.430,7.317 21.034,8.923 ZM9.788,16.367 C11.385,18.327 13.189,20.070 15.342,21.424 C15.804,21.712 16.316,21.924 16.797,22.186 C17.040,22.323 17.209,22.280 17.408,22.074 C18.138,21.325 18.881,20.588 19.624,19.851 C20.597,18.884 21.821,18.884 22.801,19.851 C23.993,21.037 25.185,22.224 26.371,23.417 C27.363,24.416 27.357,25.640 26.358,26.652 C25.684,27.332 24.966,27.982 24.330,28.693 C23.400,29.737 22.239,30.074 20.903,29.999 C18.962,29.893 17.177,29.250 15.455,28.413 C11.629,26.552 8.358,23.973 5.619,20.713 C3.590,18.302 1.917,15.673 0.819,12.713 C0.282,11.283 -0.098,9.816 0.020,8.261 C0.095,7.305 0.451,6.487 1.156,5.819 C1.917,5.095 2.635,4.339 3.384,3.602 C4.358,2.641 5.581,2.641 6.561,3.596 C7.166,4.189 7.759,4.795 8.358,5.395 C8.939,5.982 9.519,6.556 10.100,7.143 C11.123,8.173 11.123,9.373 10.106,10.397 C9.376,11.133 8.652,11.870 7.909,12.588 C7.716,12.782 7.697,12.938 7.797,13.175 C8.290,14.349 8.995,15.392 9.788,16.367 Z"/></svg></span> +91 9914940926
						</a>
					</div>
				</div>
			</div>
		</div>
	</section>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3833933780855158"
     crossorigin="anonymous"></script>

	<!-- Newsletter section end -->
	<!-- Start Footer -->
	<!-- Footer section start -->
<section class="fit_footer_wrapper">
	<div class="container">
		<div class="row">
			<div class="col-xl-7 col-lg-7">
				<div class="fit_footer_box">
					<a href="index.php"><img src="assets/images/fit1.png" class="img-fluid" alt="7 Ocean" title="7 Ocean" style="margin-top:-80px;"></a><br>
					<p class="footer_about_p" style="margin-top:-120px;">
						We welcome you to the world of health and fitness. You are at the right place as we take care of your health sincerely and provide you with regular work out and diet and nutrition. Our experts  keep in touch with you for better health. Our results are testimony of our excellence. We insure you best of health and fitness
					</p>
					<span style="color:#fff;">MSME Registration No: &nbsp;  &nbsp;UDYAM-HR-01-0038083</span><br><br>
					<ul class="common_social">
						<li>
							<a href="https://www.facebook.com/earlybirdhealthandfitness?mibextid=ZbWKwL" target="_blank" class="fit_btn social_btn">
								<svg xmlns:xlink="http://www.w3.org/1999/xlink" width="7px" height="14px"><path fill-rule="evenodd" fill="rgb(186, 186, 186)" d="M6.736,0.000 L5.057,-0.004 C3.171,-0.004 1.952,1.349 1.952,3.441 L1.952,5.031 L0.264,5.031 C0.118,5.031 -0.000,5.158 -0.000,5.316 L-0.000,7.619 C-0.000,7.776 0.118,7.903 0.264,7.903 L1.952,7.903 L1.952,13.713 C1.952,13.870 2.070,13.997 2.216,13.997 L4.418,13.997 C4.564,13.997 4.682,13.869 4.682,13.713 L4.682,7.903 L6.656,7.903 C6.802,7.903 6.920,7.776 6.920,7.619 L6.921,5.316 C6.921,5.240 6.893,5.168 6.843,5.116 C6.794,5.061 6.727,5.031 6.657,5.031 L4.682,5.031 L4.682,3.684 C4.682,3.037 4.825,2.709 5.605,2.709 L6.736,2.708 C6.881,2.708 7.000,2.580 7.000,2.422 L7.000,0.284 C7.000,0.129 6.882,0.000 6.736,0.000 Z"/></svg>
							</a>
						</li>
						<li>
							<a href="https://www.instagram.com/early_bird_health_and_fitness?igsh=MzNlNGNkZWQ4Mg==" target="_blank" class="fit_btn social_btn">
								<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
									<path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/>
								</svg>
							</a>
						</li>
						<li>
						    	<a href="https://youtube.com/@EarlyBirdhealthandfitness?si=0sTX2D2EBr-pLcwt" target="_blank" class="fit_btn social_btn">
						    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-youtube" viewBox="0 0 16 16">
  <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.01 2.01 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.01 2.01 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31 31 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.01 2.01 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A100 100 0 0 1 7.858 2zM6.4 5.209v4.818l4.157-2.408z"/>
</svg></a>
						</li>
					
					</ul>
				</div>
			</div>
			<div class="col-xl-2 col-lg-2">
				<div class="fit_footer_box">
					<h2 class="footer_title underline_title">Useful Links</h2>
					<ul class="footer_blogul">
						<li>
							<a  href="index.php"> 
								<p class="footer_blogtitle">Home</p>
							</a>
						</li>
						<li>
							<a  href="gallery.php"> 
								<p class="footer_blogtitle">Gallery</p>
							</a>
						</li>
						
						<li>
							<a  href="contact.php"> 
								<p class="footer_blogtitle">Contact Us</p>
							</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-xl-3 col-lg-3">
				<div class="fit_footer_box">
					<h2 class="footer_title underline_title">Get In Touch</h2>
					<ul class="footer_cntactul">
						<li>
							<a href="#33">
								<svg xmlns:xlink="http://www.w3.org/1999/xlink" width="20px" height="16px"><path fill-rule="evenodd" fill="rgb(46 152 192)" d="M5.530,-0.001 C2.497,-0.001 0.030,2.437 0.030,5.434 C0.030,9.152 4.952,14.611 5.161,14.841 C5.358,15.058 5.702,15.057 5.898,14.841 C6.108,14.611 11.030,9.152 11.030,5.434 C11.029,2.437 8.562,-0.001 5.530,-0.001 ZM5.530,8.167 C4.004,8.167 2.762,6.941 2.762,5.434 C2.762,3.926 4.004,2.699 5.530,2.699 C7.055,2.699 8.297,3.926 8.297,5.434 C8.297,6.941 7.055,8.167 5.530,8.167 Z"/></svg> 
							Office-   36 B- 1, Tagore Garden, Ambala
							</a>
						</li>
						
						<li>
							<a href="mailto:earlybirdhealthandfitness@gmail.com">
								<svg xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="11px"><path fill-rule="evenodd" fill="rgb(46 152 192)" d="M9.822,5.586 L15.000,0.962 L15.000,10.104 L9.822,5.586 ZM0.341,0.300 C0.534,0.114 0.793,-0.000 1.079,-0.000 L13.921,-0.000 C14.209,-0.000 14.468,0.113 14.661,0.297 L7.500,6.600 L0.341,0.300 ZM-0.000,10.104 L-0.000,0.965 L5.178,5.586 L-0.000,10.104 ZM7.500,7.699 L9.356,6.032 L14.659,10.701 C14.466,10.885 14.207,10.999 13.921,10.999 L1.079,10.999 C0.791,10.999 0.531,10.885 0.338,10.701 L5.644,6.032 L7.500,7.699 Z"/></svg>
								earlybirdhealthandfitness@gmail.com
							</a>
						</li>
						<li>
							<a href="tel:+91 9914940926">
								<svg xmlns:xlink="http://www.w3.org/1999/xlink" width="20px" height="15px"><path fill-rule="evenodd" fill="rgb(46 152 192)" d="M13.866,7.238 C13.607,5.723 12.892,4.346 11.802,3.256 C10.653,2.110 9.197,1.383 7.592,1.158 L7.755,-0.001 C9.613,0.258 11.296,1.098 12.626,2.429 C13.888,3.693 14.716,5.286 15.019,7.040 L13.866,7.238 ZM10.537,4.461 C11.296,5.223 11.796,6.182 11.977,7.241 L10.824,7.437 C10.684,6.619 10.300,5.876 9.713,5.289 C9.091,4.668 8.304,4.277 7.439,4.156 L7.601,2.997 C8.719,3.153 9.734,3.659 10.537,4.461 ZM4.909,8.183 C5.709,9.164 6.611,10.035 7.689,10.713 C7.920,10.856 8.176,10.962 8.417,11.093 C8.538,11.162 8.623,11.140 8.723,11.037 C9.088,10.662 9.460,10.294 9.831,9.926 C10.318,9.442 10.931,9.442 11.421,9.926 C12.017,10.519 12.614,11.112 13.207,11.709 C13.704,12.208 13.701,12.820 13.201,13.326 C12.864,13.666 12.505,13.991 12.186,14.347 C11.721,14.868 11.140,15.037 10.472,14.999 C9.500,14.946 8.607,14.625 7.745,14.207 C5.831,13.276 4.194,11.986 2.823,10.357 C1.808,9.151 0.971,7.836 0.422,6.357 C0.153,5.642 -0.038,4.908 0.022,4.130 C0.059,3.653 0.237,3.243 0.590,2.909 C0.971,2.547 1.330,2.170 1.705,1.801 C2.192,1.320 2.804,1.320 3.295,1.798 C3.598,2.094 3.894,2.398 4.194,2.697 C4.485,2.991 4.775,3.278 5.065,3.571 C5.578,4.087 5.578,4.687 5.069,5.199 C4.703,5.567 4.341,5.935 3.969,6.294 C3.873,6.391 3.863,6.469 3.913,6.588 C4.160,7.174 4.513,7.696 4.909,8.183 Z"/></svg>
								+91 9914940926
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>
<a  class="whats-app" href="https://wa.me/+919914940926" target="_blank">
    <i class="fa fa-whatsapp my-float"></i>
</a>
<!-- Footer section end -->
<!-- Copyright section start -->
<div class="fit_copy_wrapper bg_second">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<div class="fit_copy_box">
					<p>Copyright © 2023-24 <a href="https://360lution.com/">360lution Pvt. Ltd.</a>. All Rights Reserved</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Copyright section end -->
<!-- go to  top -->
<a href="javascript:void(0);" id="scroll">Top</a>

	<!-- End Footer -->
	<!-- Start Script -->
	<div id="myButton"></div>
        
<!-- js files start -->
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/swiper-bundle.min.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script src="assets/js/nice-select.min.js"></script>
<script src="assets/js/SmoothScroll.min.js"></script>
<script src="assets/js/custom.js"></script>	<!-- End Script -->
 <script>
  document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
  });
</script>
<script>
  document.addEventListener('keydown', function(e) {
    // Block Ctrl + U (View Source)
    if (e.ctrlKey && e.key === 'u') {
      e.preventDefault();
    }
    // Block Ctrl + Shift + I (Inspect Element)
    if (e.ctrlKey && e.shiftKey && e.key === 'I') {
      e.preventDefault();
    }
    // Block Ctrl + Shift + C (Inspect Element)
    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
      e.preventDefault();
    }
    // Block F12 (Developer Tools)
    if (e.key === 'F12') {
      e.preventDefault();
    }
  });
</script>

</body>

<!-- Mirrored from 7ocean.club/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2024 05:39:19 GMT -->
</html>
