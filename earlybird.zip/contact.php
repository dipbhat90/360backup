<?php include 'header.php'; ?>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZG3GPH80J5"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZG3GPH80J5');
</script>
<div class="sidebar_ovelay toggle_btn"></div>
<!-- Header section end -->	<!-- End Header -->
	<!-- Breadcrumb  start -->
	<div class="fit_breadcrumb_wrapper">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<h1 class="bread_title">Contact Us</h1>
					<p class="bread_subtitle">Home // Contact Us</p>
				</div>
			</div>
		</div>
	</div>
	<!-- Breadcrumb  end -->
	<!-- Location section start -->
	<section class="fit_location_wrapper">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 col-lg-8 col-md-10 col-sm-12 col-12 offset-xl-0 offset-lg-2 offset-md-1">
					<div class="fit_heading text-center">
						<h2 class="heading_title">Our Location</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-12 ">
					<div class="fit_location_inner">
						<h2 class="location_heading">Address</h2>
						<ul class="location_ul">
							<li>
								<a href="#33">
									<span class="location_svg"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="11px" height="16px"><path fill-rule="evenodd" fill="rgb(251, 91, 33)" d="M5.500,-0.000 C2.467,-0.000 -0.000,2.437 -0.000,5.432 C-0.000,9.150 4.922,14.607 5.131,14.837 C5.328,15.054 5.672,15.053 5.868,14.837 C6.078,14.607 11.000,9.150 11.000,5.432 C11.000,2.437 8.533,-0.000 5.500,-0.000 ZM5.500,8.165 C3.974,8.165 2.733,6.939 2.733,5.432 C2.733,3.925 3.974,2.699 5.500,2.699 C7.026,2.699 8.267,3.925 8.267,5.432 C8.267,6.939 7.026,8.165 5.500,8.165 Z"/></svg></span>
									<p><span>Address- Tagore Garden, Ambala City</span></p>
								</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4 col-md-12 ">
					<div class="fit_location_inner">
						<h2 class="location_heading">Mail Us</h2>
						<ul class="location_ul">
							
							<li>
								<a href="mailto:earlybirdhealthandfitness@gmail.com">
									<span class="location_svg"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="12px" height="9px"><path fill-rule="evenodd" fill="rgb(251, 91, 33)" d="M7.857,4.571 L12.000,0.787 L12.000,8.267 L7.857,4.571 ZM0.272,0.245 C0.427,0.094 0.634,-0.000 0.863,-0.000 L11.137,-0.000 C11.367,-0.000 11.575,0.092 11.729,0.244 L6.000,5.400 L0.272,0.245 ZM-0.000,8.267 L-0.000,0.790 L4.142,4.571 L-0.000,8.267 ZM6.000,6.300 L7.485,4.935 L11.727,8.755 C11.573,8.907 11.365,9.000 11.137,9.000 L0.863,9.000 C0.633,9.000 0.425,8.907 0.271,8.755 L4.515,4.935 L6.000,6.300 Z"/></svg></span>
									<p><span class="d-block">earlybirdhealthandfitness@gmail.com</span></p>
								</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4 col-md-12 ">
					<div class="fit_location_inner">
						<h2 class="location_heading">Call Us</h2>
						<ul class="location_ul">
							<li>
								<a href="tel:+91 9914940926">
									<span class="location_svg"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="14px" height="14px"><path fill-rule="evenodd" fill="rgb(251, 91, 33)" d="M12.913,6.755 C12.671,5.342 12.003,4.057 10.986,3.039 C9.913,1.970 8.555,1.291 7.057,1.081 L7.208,-0.000 C8.943,0.242 10.514,1.026 11.755,2.267 C12.933,3.447 13.706,4.933 13.988,6.572 L12.913,6.755 ZM9.805,4.164 C10.514,4.875 10.980,5.770 11.149,6.758 L10.074,6.941 C9.942,6.178 9.584,5.484 9.036,4.936 C8.456,4.357 7.721,3.992 6.914,3.879 L7.066,2.797 C8.109,2.943 9.056,3.415 9.805,4.164 ZM4.553,7.638 C5.299,8.553 6.142,9.366 7.147,9.999 C7.363,10.133 7.602,10.232 7.826,10.354 C7.940,10.418 8.019,10.398 8.112,10.302 C8.453,9.952 8.800,9.608 9.147,9.264 C9.601,8.813 10.173,8.813 10.630,9.264 C11.187,9.818 11.744,10.372 12.298,10.928 C12.761,11.395 12.758,11.966 12.292,12.438 C11.977,12.755 11.642,13.058 11.344,13.391 C10.910,13.877 10.368,14.035 9.744,14.000 C8.838,13.950 8.004,13.650 7.200,13.260 C5.413,12.391 3.885,11.188 2.606,9.666 C1.658,8.542 0.877,7.315 0.364,5.933 C0.114,5.266 -0.064,4.581 -0.009,3.855 C0.026,3.409 0.192,3.028 0.522,2.716 C0.877,2.378 1.212,2.025 1.562,1.681 C2.017,1.232 2.588,1.232 3.046,1.678 C3.329,1.955 3.606,2.238 3.885,2.518 C4.156,2.792 4.428,3.060 4.699,3.334 C5.177,3.815 5.177,4.374 4.702,4.852 C4.361,5.196 4.022,5.540 3.676,5.875 C3.585,5.965 3.576,6.038 3.623,6.149 C3.853,6.697 4.183,7.183 4.553,7.638 Z"/></svg></span>
									<p><span class="d-block">+91 9914940926</span></p>
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Location section end -->
	<!-- Get in touch section start -->
	<section class="fit_map_wrapper">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="fit_getintouch">
						<h2 class="underline_title">Get In Touch</h2>
						<form action="mailsent.php" method="post">
							<div class="row">
								<div class="col-md-12">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="text" placeholder="Name" name="name" required>
									</div>
								</div>
								<div class="col-md-12">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="email" placeholder="Email" name="email" required>
									</div>
								</div>
								<div class="col-md-12">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="number" placeholder="Mobile Number" name="phone" required>
									</div>
								</div>
							
								<div class="col-12">
									<div class="fit_form_field mb_30">
										<textarea placeholder="Comment here..." class="fit_field_inner require" name="message" id="message"></textarea>
									</div>
								</div>
								<div class="col-12">
									<div class="fit_form_field mb_30">
										<input name="submit" type="button" class="fit_btn btn2 submitForm" value="Submit" style="background: rgb(46 152 192);"/>
									</div>
								</div>
								<div class="col-12">
									<div class="fit_form_field">
										<a name="success"></a>
																			</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="fit_map">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3507.031984504609!2d77.07814831455605!3d28.47858339778376!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d19a4800bfc9b%3A0xbbcb78bc792a0898!2s7%20Ocean%20-%20The%20Fitness%20Club!5e0!3m2!1sen!2sin!4v1677234923904!5m2!1sen!2sin" height="100%" aria-hidden="false" tabindex="0"></iframe>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Get in touch section end -->
<?php include 'footer.php'; ?>