<?php include 'header.php'; ?>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZG3GPH80J5"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZG3GPH80J5');
</script>
<div class="sidebar_ovelay toggle_btn"></div>
<!-- Header section end -->	<!-- End Header -->
	<!-- Start Slider -->
	<div class="slider" id="home">
	<div id="demo1">
	
		<div class="slide">
			<img src="assets/images/banner/slider6.jpeg" alt="7 Ocean"  style="height:600px;">
		</div>
		<div class="slide">
			<img src="assets/images/banner/slider3.jpeg" alt="7 Ocean"  style="height:600px;">
		</div>
			<div class="slide">
			<img src="assets/images/banner/slider4.jpeg" alt="7 Ocean"  style="height:600px;">
		</div>
			<div class="slide">
			<img src="assets/images/banner/slider5.jpeg" alt="7 Ocean"  style="height:600px;">
		</div>
	</div>
</div>	<!-- End Slider -->
<section class="fit_map_wrapper">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="fit_getintouch">
						<h2 class="underline_title">Get In Touch</h2>
						<form action="mail.php" method="post">
							<div class="row">
								<div class="col-md-6">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="text" placeholder="Name" name="name" required>
									</div>
								</div>
								<div class="col-md-6">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="text" placeholder="Age" name="age" required>
									</div>
								</div>
								<div class="col-md-6">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="text" placeholder="Height" name="hight" required>
									</div>
								</div>
								<div class="col-md-6">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="text" placeholder="Weight" name="weight" required>
									</div>
								</div>
									<div class="col-md-6">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="text" placeholder="Locality" name="locality" required>
									</div>
								</div>
								<div class="col-md-6">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="text" placeholder="Health Goal" name="health" required>
									</div>
								</div>
								
								<div class="col-md-6">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="number" placeholder="Mobile Number" name="phone" required>
									</div>
								</div>
									<div class="col-md-6">
									<div class="fit_form_field mb_30">
										<input class="fit_field_inner require" type="email" placeholder="E-mail" name="email" required>
									</div>
								</div>
								
								<div class="col-12">
									<div class="fit_form_field mb_30">
										<input name="submit" type="submit" class="fit_btn btn2 submitForm" value="Submit" style="background: rgb(46 152 192);"/>
									</div>
								</div>
								<div class="col-12">
									<div class="fit_form_field">
										<a name="success"></a>
																			</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="fit_map">
						<img src="assets/images/banner/slider.jpeg" style="height:600px;">
					</div>
				</div>
			</div>
		</div>
	</section>
	<div class="about_bg_wrap">
		<!-- About section start -->
		<section class="fit_about_wrapper pt_100 pb_150">
			<div class="container">
				<div class="row">
					<div class="col-xl-12 col-lg-8 col-md-10 col-sm-12 col-12 offset-xl-0 offset-lg-2 offset-md-1">
						<div class="fit_heading text-center">
							<h2 class="heading_title">About US</h2>
							<p style="padding: 0px;">
								 At our fitness company, we're committed to providing content that not only motivates but also educates and inspires our community to reach their health and wellness goals. 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-md-12 ">
						<div class="fit_about_img">
							<!-- Slider -->
							<div class="swiper-container">
								<div class="swiper-wrapper">
									<div class="">
										<div class="about_inner">
											<img src="assets/images/about/1.jpeg" class="img-fluid" alt="7 Ocean" title="7 Ocean" style="height:600px;width:500px;">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-12 ">
						<div class="fit_about_content">
							<h1 class="about_heading">Who We Are</h1>
							<p>
								At our core, we are champions of transformation, advocates for resilience, and believers in the power of the human spirit. We are more than just a fitness company; we are a community bound by the shared pursuit of vitality and strength. Every step, every lift, every stretch is a testament to our dedication to self-improvement and well-being. We are the embodiment of perseverance, pushing through barriers and conquering obstacles with unwavering determination.
							</p>
							<p>
								Our ethos is built on inclusivity and support, fostering an environment where individuals of all backgrounds and abilities can thrive. Together, we celebrate victories, both big and small, knowing that each milestone brings us closer to our fullest potential. In every workout, in every interaction, we strive to inspire and empower, recognizing that true fulfillment comes not only from physical prowess but also from the journey of self-discovery and growth. This is who we are—a beacon of strength, unity, and unwavering commitment to the pursuit of a healthier, happier life.





							</p>
							
						</div>
					</div>
				</div>
			</div>
		</section>
	  <!-- About section end -->
	</div>
	<!-- Service section start -->
	<section class="fit_service_wrapper bg_second shap st sb " style="margin-top:-50px;">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 col-lg-8 col-md-10 col-sm-12 col-12 offset-xl-0 offset-lg-2 offset-md-1">
					<div class="fit_heading text-center " style="margin-top:-90px;">
						<h2 class="heading_title mt-0">Our Classes</h2>
						<p>It is not easy to be consistent with workout, we need assortments in exercise as well. That is when our fitness classes come to rescue.</p>
					</div>
				</div>
			</div>
			<div class="row">
			
				<div class="col-lg-4 col-sm-6">
					<div class="fit_servicebox">
						<span>
							<img src="assets/images/class/2.png" alt="Yoga" title="Yoga">
						</span>
						<h2>Yoga</h2>
						<p>
							Yoga, a serene & spiritual discipline based on a subtle science, which focuses on bringing harmony between mind and body. 
						</p>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="fit_servicebox">
						<span>
							<img src="assets/images/class/3.png" alt="Nutritionist" title="Nutritionist">
						</span>
						<h2>Nutritionist</h2>
						<p>
							Diet Plan is the most crucial part of fitness. At early bird health and fitness, we got that covered for you. With our In-house expert in food and nutrition, you receive the 
							right advice on eating right
						</p>
					</div>
				</div>
					<div class="col-lg-4 col-sm-6">
					<div class="fit_servicebox">
						<span>
							<img src="assets/images/class/on.jpg" alt="Nutritionist" title="Nutritionist" style="height:50px;">
						</span>
						<h2>Online Workout</h2>
						<p>
						Online workout content has become increasingly popular, offering a wide range of options to cater to different fitness levels, preferences, and goals.
						</p>
					</div>
				</div>
				
			
			</div>
		</div>
	</section>
	<!-- Service section end -->
	<!-- Trainer section start -->
	<section class="fit_trainer_wrapper trainer_bgimg common_bg shap pt_100 pb_150">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 col-lg-8 col-md-10 col-sm-12 col-12 offset-xl-0 offset-lg-2 offset-md-1">
					<div class="fit_heading text-center" style="margin-top:-90px;">
						<h2 class="heading_title">Our Team</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="offset-md-1 col-md-10">
					<div class="fit_trainer_inner">
						<!-- Slider for tainer -->
						<div class="swiper-container">
							<div class="swiper-wrapper">
							    	<div class="swiper-slide">
									<div class="trainer_inner_slider">
										<div class="inner_slider_img">
											<img src="assets/images/team/team1.jpg" class="img-fluid" alt="Avneet Sharma" title="Avneet Sharma" style="height:300px;">
										
										</div>
										<h1 class="fit_trainer_title">Vandana</h1>
										<p class="trainer_desig">Health and Wellness Coach</p>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="trainer_inner_slider">
										<div class="inner_slider_img">
											<img src="assets/images/team/team.jpg" class="img-fluid" alt="Sandeep Solanki" title="Sandeep Solanki" style="height:300px;">
											
										</div>
										<h1 class="fit_trainer_title">Anu </h1>
										<p class="trainer_desig">Health and Wellness Coach</p>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="trainer_inner_slider">
										<div class="inner_slider_img">
											<img src="assets/images/team/testi1.jpg" class="img-fluid" alt="Avneet Sharma" title="Avneet Sharma" style="height:300px;">
										
										</div>
										<h1 class="fit_trainer_title">Mukesh Kumar</h1>
										<p class="trainer_desig">Founder</p>
									</div>
								</div>
									<div class="swiper-slide">
									<div class="trainer_inner_slider">
										<div class="inner_slider_img">
											<img src="assets/images/team/team3.jpeg" class="img-fluid" alt="Avneet Sharma" title="Avneet Sharma" style="height:300px;">
										
										</div>
										<h1 class="fit_trainer_title">Acharya Anupam</h1>
									
									</div>
								</div>
									<div class="swiper-slide">
									<div class="trainer_inner_slider">
										<div class="inner_slider_img">
											<img src="assets/images/team/team4.jpeg" class="img-fluid" alt="Avneet Sharma" title="Avneet Sharma" style="height:300px;">
										
										</div>
										<h1 class="fit_trainer_title">Priyanka Mehta</h1>
										<p class="trainer_desig">Yoga Expert<br>IIYM</p>
									
									</div>
								</div>
							
							
							
							</div>
						</div>
						<!-- Add Arrows -->
						<div class="swiper-button-next trainer_nav">
							<span class="about_nav"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="13px" height="17px"><path fill-rule="evenodd"  fill="rgb(255, 255, 255)" d="M12.819,8.164 L0.657,0.067 C0.529,-0.019 0.362,-0.027 0.224,0.042 C0.086,0.112 -0.000,0.250 -0.000,0.400 L-0.000,16.594 C-0.000,16.745 0.086,16.883 0.224,16.953 C0.286,16.983 0.353,16.999 0.419,16.999 C0.503,16.999 0.586,16.975 0.657,16.927 L12.819,8.830 C12.932,8.755 13.000,8.631 13.000,8.498 C13.000,8.365 12.932,8.240 12.819,8.164 ZM0.839,15.823 L0.839,1.171 L11.842,8.498 L0.839,15.823 Z"/></svg></span>
						</div>
						<div class="swiper-button-prev trainer_nav">
							<span class="about_nav"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="13px" height="17px"><path fill-rule="evenodd" fill="rgb(255, 255, 255)" d="M0.181,8.164 L12.342,0.067 C12.471,-0.019 12.638,-0.027 12.776,0.042 C12.914,0.112 13.000,0.250 13.000,0.400 L13.000,16.594 C13.000,16.745 12.914,16.883 12.776,16.953 C12.714,16.983 12.647,16.999 12.581,16.999 C12.497,16.999 12.414,16.975 12.342,16.927 L0.181,8.830 C0.067,8.755 -0.000,8.631 -0.000,8.498 C-0.000,8.365 0.068,8.240 0.181,8.164 ZM12.161,15.823 L12.161,1.171 L1.158,8.498 L12.161,15.823 Z"/></svg></span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Trainer section end -->
		<section class="fit_blog_wrapper bg_second shap pt_100 pb_185">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 col-lg-8 col-md-10 col-sm-12 col-12 offset-xl-0 offset-lg-2 offset-md-1">
					<div class="fit_heading text-center" style="margin-top:-90px;">
						<h2 class="heading_title">Our Services</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="fit_trainer_inner">
						<!-- Slider for Blog -->
						<div class="swiper-container">
							<div class="swiper-wrapper">
								<div class="swiper-slide">
									<div class="blog_inner_slider">
										<div class="blog_img">
											<img src="assets/images/pic4.jpeg" class="img-fluid" alt="blog" style="height:400px;padding:20px;border-radius:50px;">
										</div>
									
									</div>
								</div>
								<div class="swiper-slide">
									<div class="blog_inner_slider">
										<div class="blog_img">
											<img src="assets/images/pic5.jpeg" class="img-fluid" alt="blog" style="height:400px;padding:20px;border-radius:50px;">
										</div>
									
									</div>
								</div>
								<div class="swiper-slide">
									<div class="blog_inner_slider">
										<div class="blog_img">
											<img src="assets/images/pic6.jpeg" class="img-fluid" alt="blog" style="height:400px;padding:20px;border-radius:50px;">
										</div>
									
									</div>
								</div>
								<div class="swiper-slide">
									<div class="blog_inner_slider">
										<div class="blog_img">
											<img src="assets/images/pic7.jpeg" class="img-fluid" alt="blog" style="height:400px;padding:20px;border-radius:50px;">
										</div>
									
									</div>
								</div>
							</div>
						</div>
						<!-- Add Pagination -->
						<div class="swiper-pagination"></div>
						<!-- Add Arrows -->
						<div class="swiper-button-next trainer_nav">
							<span class="about_nav"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="13px" height="17px"><path fill-rule="evenodd"  fill="rgb(255, 255, 255)" d="M12.819,8.164 L0.657,0.067 C0.529,-0.019 0.362,-0.027 0.224,0.042 C0.086,0.112 -0.000,0.250 -0.000,0.400 L-0.000,16.594 C-0.000,16.745 0.086,16.883 0.224,16.953 C0.286,16.983 0.353,16.999 0.419,16.999 C0.503,16.999 0.586,16.975 0.657,16.927 L12.819,8.830 C12.932,8.755 13.000,8.631 13.000,8.498 C13.000,8.365 12.932,8.240 12.819,8.164 ZM0.839,15.823 L0.839,1.171 L11.842,8.498 L0.839,15.823 Z"/></svg></span>
						</div>
						<div class="swiper-button-prev trainer_nav">
							<span class="about_nav"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="13px" height="17px"><path fill-rule="evenodd" fill="rgb(255, 255, 255)" d="M0.181,8.164 L12.342,0.067 C12.471,-0.019 12.638,-0.027 12.776,0.042 C12.914,0.112 13.000,0.250 13.000,0.400 L13.000,16.594 C13.000,16.745 12.914,16.883 12.776,16.953 C12.714,16.983 12.647,16.999 12.581,16.999 C12.497,16.999 12.414,16.975 12.342,16.927 L0.181,8.830 C0.067,8.755 -0.000,8.631 -0.000,8.498 C-0.000,8.365 0.068,8.240 0.181,8.164 ZM12.161,15.823 L12.161,1.171 L1.158,8.498 L12.161,15.823 Z"/></svg></span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	

	<!-- Testimonial section start -->
	<section class="fit_testimonial_wrapper testi_bgimg common_bg shap">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 col-lg-8 col-md-10 col-sm-12 col-12 offset-xl-0 offset-lg-2 offset-md-1">
					<div class="fit_heading text-center" style="margin-top:-90px;">
						<h2 class="heading_title">Testimonial</h2>
					</div>
				</div>
			</div>
			<div class="row align-items-center">
				<div class="col-lg-12 col-md-12">
					<div class="fit_testi_wrap">
						<!-- Slider -->
						<div class="swiper-container">
							<div class="swiper-wrapper">
								<div class="swiper-slide">
									<div class="test_inner_slider">
										<div class="test_img">
											<img src="assets/images/team/testi3.jpg" class="img-fluid" alt="7 Ocean" title="7 Ocean">
										</div>
										<h2>Anu</h2>
										<p class="testimonial_designtn"></p>
										<div class="testimonial_data">
											<p>
												I am thankful to early Bird Health and Fitness for transforming my life.I lost 15 kgs in less than 3 months. I not only lost body fat but also many health issues like migrane, cervical. I highly recommend their services for effective weight loss.🙌
											</p>
											<span class="testimonial_quote"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="122px" height="91px"><path fill-rule="evenodd" opacity="0.039" fill="rgb(255, 255, 255)" d="M76.250,90.998 L76.250,-0.001 L122.000,-0.001 L122.000,45.499 L76.250,90.998 ZM-0.000,-0.001 L45.750,-0.001 L45.750,45.499 L-0.000,90.998 L-0.000,-0.001 Z"/></svg></span>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="test_inner_slider">
										<div class="test_img">
											<img src="assets/images/team/testi4.jpg" class="img-fluid" alt="7 Ocean" title="7 Ocean">
										</div>
										<h2> Satnam Singh<br>Professor</h2>
										<p class="testimonial_designtn"></p>
										<div class="testimonial_data">
											<p>
												Early Bird Health and Fitness has changed my life. I used to feel devoid of energy and stamina. Now I have gained the lost energy and stamina. Thank you for transforming my life
											</p>
											<span class="testimonial_quote"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="122px" height="91px"><path fill-rule="evenodd" opacity="0.039" fill="rgb(255, 255, 255)" d="M76.250,90.998 L76.250,-0.001 L122.000,-0.001 L122.000,45.499 L76.250,90.998 ZM-0.000,-0.001 L45.750,-0.001 L45.750,45.499 L-0.000,90.998 L-0.000,-0.001 Z"/></svg></span>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="test_inner_slider">
										<div class="test_img">
											<img src="assets/images/team/testi.jpg" class="img-fluid" alt="7 Ocean" title="7 Ocean">
										</div>
										<h2>Amit Sharma<br>Advocate</h2>
										<p class="testimonial_designtn"></p>
										<div class="testimonial_data">
											<p>
												Wow! What an experience being with Early bird and fitness! 
It has ushered utter transformation in my life- my Odyssey from being fat to fit kick started six months back when I joined them, consummating in shedding off many kilos of fat that weighed me heavy! 

What more to say- I was never made reliant on any supplements or drugs rather they rendered my health metamorphosis with a return to nature motto - exercising around 20 minutes a day- eating heathy worked wonders! 

Join them if you love yourself ! 

Join and see the changes.
											</p>
											<span class="testimonial_quote"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="122px" height="91px"><path fill-rule="evenodd" opacity="0.039" fill="rgb(255, 255, 255)" d="M76.250,90.998 L76.250,-0.001 L122.000,-0.001 L122.000,45.499 L76.250,90.998 ZM-0.000,-0.001 L45.750,-0.001 L45.750,45.499 L-0.000,90.998 L-0.000,-0.001 Z"/></svg></span>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="test_inner_slider">
										<div class="test_img">
											<img src="assets/images/team/testi2.jpg" class="img-fluid" alt="7 Ocean" title="7 Ocean">
										</div>
										<h2>B.Singhal, Educationist</h2>
										<p class="testimonial_designtn"></p>
										<div class="testimonial_data">
											<p>
											Early bird Health and Fitness changed my personality as I have been gaining weight consistently. They helped me recover from this and now I lead happy and healthy life.Thanks a lot.
											</p>
											<span class="testimonial_quote"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="122px" height="91px"><path fill-rule="evenodd" opacity="0.039" fill="rgb(255, 255, 255)" d="M76.250,90.998 L76.250,-0.001 L122.000,-0.001 L122.000,45.499 L76.250,90.998 ZM-0.000,-0.001 L45.750,-0.001 L45.750,45.499 L-0.000,90.998 L-0.000,-0.001 Z"/></svg></span>
										</div>
									</div>
								</div>
									<div class="swiper-slide">
									<div class="test_inner_slider">
										<div class="test_img">
											<img src="assets/images/team/testi5.jpeg" class="img-fluid" alt="7 Ocean" title="7 Ocean">
										</div>
										<h2>Ravi Kaler<br>Qatar</h2>
										<p class="testimonial_designtn"></p>
										<div class="testimonial_data">
											<p>
										EB guided me the importance of diet and Nutrition. When I lost weight it was amazing. I felt easy doing daily life routine.
											</p>
											<span class="testimonial_quote"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="122px" height="91px"><path fill-rule="evenodd" opacity="0.039" fill="rgb(255, 255, 255)" d="M76.250,90.998 L76.250,-0.001 L122.000,-0.001 L122.000,45.499 L76.250,90.998 ZM-0.000,-0.001 L45.750,-0.001 L45.750,45.499 L-0.000,90.998 L-0.000,-0.001 Z"/></svg></span>
										</div>
									</div>
								</div>
									<div class="swiper-slide">
									<div class="test_inner_slider">
										<div class="test_img">
											<img src="assets/images/team/testi6.jpeg" class="img-fluid" alt="7 Ocean" title="7 Ocean">
										</div>
										<h2>Vandana<br>Educationist </h2>
										<p class="testimonial_designtn"></p>
										<div class="testimonial_data">
											<p>
									
It was not easy for me to get in shape after having so many health issues but Early Bird has been my constant companion to guide me to better health.
											</p>
											<span class="testimonial_quote"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="122px" height="91px"><path fill-rule="evenodd" opacity="0.039" fill="rgb(255, 255, 255)" d="M76.250,90.998 L76.250,-0.001 L122.000,-0.001 L122.000,45.499 L76.250,90.998 ZM-0.000,-0.001 L45.750,-0.001 L45.750,45.499 L-0.000,90.998 L-0.000,-0.001 Z"/></svg></span>
										</div>
									</div>
								</div>
							
							
							</div>
							<!-- Add Arrows -->
							<div class="testimonial_nav color_nav">
								<div class="testimonialPrev">
									<span class="about_nav mr-2"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="13px" height="17px"><path fill-rule="evenodd" fill="rgb(255, 255, 255)" d="M0.181,8.164 L12.342,0.067 C12.471,-0.019 12.638,-0.027 12.776,0.042 C12.914,0.112 13.000,0.250 13.000,0.400 L13.000,16.594 C13.000,16.745 12.914,16.883 12.776,16.953 C12.714,16.983 12.647,16.999 12.581,16.999 C12.497,16.999 12.414,16.975 12.342,16.927 L0.181,8.830 C0.067,8.755 -0.000,8.631 -0.000,8.498 C-0.000,8.365 0.068,8.240 0.181,8.164 ZM12.161,15.823 L12.161,1.171 L1.158,8.498 L12.161,15.823 Z"/></svg></span>
								</div>
								<div class="testimonialNext">
									<span class="about_nav"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="13px" height="17px"><path fill-rule="evenodd"  fill="rgb(255, 255, 255)" d="M12.819,8.164 L0.657,0.067 C0.529,-0.019 0.362,-0.027 0.224,0.042 C0.086,0.112 -0.000,0.250 -0.000,0.400 L-0.000,16.594 C-0.000,16.745 0.086,16.883 0.224,16.953 C0.286,16.983 0.353,16.999 0.419,16.999 C0.503,16.999 0.586,16.975 0.657,16.927 L12.819,8.830 C12.932,8.755 13.000,8.631 13.000,8.498 C13.000,8.365 12.932,8.240 12.819,8.164 ZM0.839,15.823 L0.839,1.171 L11.842,8.498 L0.839,15.823 Z"/></svg></span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	

	<!-- Testimonial section end -->
	 
		<section class="fit_blog_wrapper bg_second our_blog pt_100 pb_100" style="display:none;">
		   <h3 style="text-align:center;">Get EB T-shirt</h3><br>
		<div class="container">
			<div class="row" style="padding-bottom:25px;">
				<div class="col-lg-3 col-md-12">
					<a href="assets/images/yoga.webp" class="example-image-link" data-lightbox="example-set" data-title="7 Ocean The Fitness Club">
						<img src="assets/images/t.jpeg" class="example-image" alt="7 Ocean The Fitness Club" title="7 Ocean The Fitness Club" style="height:300px;border-radius:10px;">
					</a>
				</div>
				<div class="col-lg-3 col-md-12">
					<a href="assets/images/yoga1.jpg" class="example-image-link" data-lightbox="example-set" data-title="7 Ocean The Fitness Club">
						<img src="assets/images/t1.jpeg" class="example-image" alt="7 Ocean The Fitness Club" title="7 Ocean The Fitness Club" style="height:300px;border-radius:10px;">
					</a>
				</div>
					
			
				
			</div>
		
		
			
		
		</div>
	</section>
<?php include 'footer.php'; ?>