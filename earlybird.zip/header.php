<!doctype html>
<html lang="eng">

<!-- Mirrored from 7ocean.club/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2024 05:39:03 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3833933780855158"
     crossorigin="anonymous"></script>

    <title></title>
        <meta name="description" content=""/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon links-->

<!-- main css -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
<link rel="stylesheet" href="assets/css/magnific-popup.css">
<link rel="stylesheet" href="assets/css/nice-select.css">
<link rel="stylesheet" href="assets/css/fonts.css">
<link rel="stylesheet" href="assets/css/style.css">

<!-- Google tag (gtag.js) --> 
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZG3GPH80J5"></script> 
<script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} 
gtag('js', new Date()); gtag('config', 'G-ZG3GPH80J5'); </script>


<script src="assets/js/jquery.min.js"></script>
<script src="src/skdslider.min.js"></script>
<link href="src/skdslider.css" rel="stylesheet">
<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('#demo1').skdslider({
		slideSelector: '.slide',
		delay:5000,
		animationSpeed:2000,
		showNextPrev:true,
		showPlayButton:false,
		autoSlide:true,
		animationType:'sliding'
	});

	jQuery('#demo2').skdslider({
		slideSelector: '.slide',
		delay:5000, 
		animationSpeed: 1000,
		showNextPrev:true,
		showPlayButton:false,
		autoSlide:true,
		animationType:'sliding'
	});
	});
</script>
<link rel="stylesheet" href="whatsapp/assets/css/floating-wpp.css">
<script type="text/javascript" src="whatsapp/assets/js/floating-wpp.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Oswald&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.whats-app {
    position: fixed;
    width: 50px;
    height: 50px;
    bottom: 30px;
    right: 15px;
    background-color: #25d366;
    color: #FFF;
    border-radius: 50px;
    text-align: center;
    font-size: 30px;
    box-shadow: 2px 2px 3px #999;
    z-index: 100;
}

.my-float {
    margin-top: 10px;
}
</style>
</head>
<body>
	<!-- Start Header -->
	<!-- Header section start -->


<header class="fit_header_wrapper" style="height:80px;">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-3 col-md-4 col-sm-4 col-6">
				<div class="fit_logo">
					<a href="index.php">
						<img src="assets/images/fit1.png" class="" alt="7 Ocean" title="7 Ocean" style="height:200px;margin-top:-50px;width:800px;">
						
					</a>
				</div>
			</div>
			<div class="col-lg-9 col-md-8 col-sm-8 col-6">
				<div class="fit_main_menu main_menu_parent">
					<!-- Header Menus -->
					<div class="fit_nav_items main_menu_wrapper text-right" style="margin-top:-80px;">
						<ul>
							<li class="mobile_logo">
								<a href="index.php">
								<img src="assets/images/fit1.png" class="img-fluid" alt="7 Ocean" title="7 Ocean" style="height:180px;width:800px;margin-top:30px;">
								
								</a>
							</li>
							<li><a href="index.php">Home</a></li>
							<li><a href="about.php">About Us</a></li>
							
							<li><a href="gallery.php">Gallery</a></li>
						
							<li><a href="contact.php">Contact Us</a></li>
						</ul>
					</div>
					<div class="fit_search_wrapper menu_btn_wrap" style="margin-top:-80px;">
						<ul class="header_social social_icon">
							<li>
								<a href="https://www.facebook.com/earlybirdhealthandfitness?mibextid=ZbWKwL" target="_blank" class="">
									<svg xmlns:xlink="http://www.w3.org/1999/xlink" width="7px" height="14px"><path fill-rule="evenodd" fill="rgb(186, 186, 186)" d="M6.736,0.000 L5.057,-0.004 C3.171,-0.004 1.952,1.349 1.952,3.441 L1.952,5.031 L0.264,5.031 C0.118,5.031 -0.000,5.158 -0.000,5.316 L-0.000,7.619 C-0.000,7.776 0.118,7.903 0.264,7.903 L1.952,7.903 L1.952,13.713 C1.952,13.870 2.070,13.997 2.216,13.997 L4.418,13.997 C4.564,13.997 4.682,13.869 4.682,13.713 L4.682,7.903 L6.656,7.903 C6.802,7.903 6.920,7.776 6.920,7.619 L6.921,5.316 C6.921,5.240 6.893,5.168 6.843,5.116 C6.794,5.061 6.727,5.031 6.657,5.031 L4.682,5.031 L4.682,3.684 C4.682,3.037 4.825,2.709 5.605,2.709 L6.736,2.708 C6.881,2.708 7.000,2.580 7.000,2.422 L7.000,0.284 C7.000,0.129 6.882,0.000 6.736,0.000 Z"/></svg>
								</a>
							</li>
							<li>
								<a href="https://www.instagram.com/early_bird_health_and_fitness?igsh=MzNlNGNkZWQ4Mg==" target="_blank" class="">
									<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
										<path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/>
									</svg>
								</a>
							</li>
							<li>
							    <a href="https://youtube.com/@EarlyBirdhealthandfitness?si=0sTX2D2EBr-pLcwt" target="_blank" class="">
							    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-youtube" viewBox="0 0 16 16">
  <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.01 2.01 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.01 2.01 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31 31 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.01 2.01 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A100 100 0 0 1 7.858 2zM6.4 5.209v4.818l4.157-2.408z"/>
</svg></a>
							</li>
						
							<li>
								<a href="javascript:void(0);" class="menu_btn toggle_btn" >
									<span></span>
									<span></span>
									<span></span>
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>